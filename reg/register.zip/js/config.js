window._config = {
    cognito: {
        userPoolId: 'us-east-1_iJmCnJKT1', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-1', // e.g. us-east-2
		clientId: '1m2jroiulkk2kdjki4ibrkfcjm' //is this used anywhere?
    }
};
